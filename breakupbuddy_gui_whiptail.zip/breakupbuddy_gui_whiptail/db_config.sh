#!/bin/bash
DB_USER="root"
DB_PASS="Subbu@999"
DB_HOST="192.168.0.102"
DB_PORT="3308"
DB_NAME="breakupbuddy"
